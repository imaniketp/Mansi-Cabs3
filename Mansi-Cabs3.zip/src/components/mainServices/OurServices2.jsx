import React from 'react'
import './OurServices.css'

function OurServices2() {
  return (
    <div className='ourservicespage'>
      <h1>One Way Trip</h1>
      <hr/>
      <div className='ourservicespagediv'>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio harum provident ipsam. Sapiente rem cumque vel laborum cum voluptatibus dolorem, corporis quas id. Alias quis libero nisi! Itaque, culpa dolor. Lorem ipsum, dolor sit amet consectetur adipisicing elit. A amet enim repellendus optio molestiae ipsa officiis tenetur eum obcaecati vero consectetur, quas libero commodi facilis consequuntur pariatur expedita culpa architecto!</p>
        <img src="oneway.jpeg" alt="roundtrip" />
      </div>
      <div className='ourservicespagediv'>
        <img src="oneway.jpeg" alt="roundtrip" />
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Expedita sit sequi alias rem nisi reprehenderit eligendi labore ratione culpa maxime placeat, quod vero, minus temporibus eveniet, iste incidunt consequatur! Nihil. Lorem ipsum, dolor sit amet consectetur adipisicing elit. A amet enim repellendus optio molestiae ipsa officiis tenetur eum obcaecati vero consectetur, quas libero commodi facilis consequuntur pariatur expedita culpa architecto!</p>
      </div>
      <div className='ourservicespagediv'>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sunt tempora corporis doloribus placeat sapiente quas incidunt laboriosam ad autem molestiae sequi expedita, repellat sed delectus est. Consequuntur atque voluptatem magni. Lorem ipsum, dolor sit amet consectetur adipisicing elit. A amet enim repellendus optio molestiae ipsa officiis tenetur eum obcaecati vero consectetur, quas libero commodi facilis consequuntur pariatur expedita culpa architecto!</p>
        <img src="oneway.jpeg" alt="roundtrip" />
      </div>
      <div className='ourservicespagediv'>
        <img src="oneway.jpeg" alt="roundtrip" />
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam earum explicabo harum fugiat itaque. Ipsam optio voluptate cupiditate libero accusamus illum excepturi praesentium quo atque vitae. Sequi inventore nesciunt ipsa. Lorem ipsum, dolor sit amet consectetur adipisicing elit. A amet enim repellendus optio molestiae ipsa officiis tenetur eum obcaecati vero consectetur, quas libero commodi facilis consequuntur pariatur expedita culpa architecto!</p>
      </div>
    </div>
  )
}

export default OurServices2